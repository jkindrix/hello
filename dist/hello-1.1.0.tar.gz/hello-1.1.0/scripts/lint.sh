#!/usr/bin/env bash
# Run clang-tidy against all C sources using compile_commands.json.
set -euo pipefail

cd "$(dirname "$0")/.."

if ! command -v clang-tidy >/dev/null 2>&1; then
    echo "error: clang-tidy not found in PATH" >&2
    exit 1
fi

BUILD_DIR="${BUILD_DIR:-build/debug}"
if [ ! -f "$BUILD_DIR/compile_commands.json" ]; then
    echo "error: $BUILD_DIR/compile_commands.json not found." >&2
    echo "       Run: cmake --preset debug" >&2
    exit 1
fi

mapfile -t files < <(find src tests examples -name '*.c' -not -path '*/build/*')

if [ ${#files[@]} -eq 0 ]; then
    echo "no source files found"
    exit 0
fi

# -Wno-unknown-warning-option silences clang-tidy's complaint about
# GCC-specific flags (-Wduplicated-cond, -Wlogical-op, ...) that get baked
# into compile_commands.json when the project was configured with GCC.
clang-tidy \
    -p "$BUILD_DIR" \
    --extra-arg-before=-Wno-unknown-warning-option \
    --warnings-as-errors='*' \
    "${files[@]}"
